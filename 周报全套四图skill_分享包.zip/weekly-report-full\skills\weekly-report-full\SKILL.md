---
name: weekly-report-full
description: 把物料中台周报 Excel 一次性生成四张 PNG 图（周报可视化图 + 动画/影剧综/纪录片 TOP&BOTTOM case 列表图），统一输出到同一文件夹。当用户说"生成周报全套"、"输出四张图"、"周报和 TOP/BOTTOM 一起出"，或拖入物料中台周报 xlsx 要求一次出全部图时使用。
---

# 周报全套四图

把物料中台周报 Excel 的「3-有运营物料season转化」+「4/5/6-物料枚举」数据，一次生成四张 PNG 图，统一输出到同一文件夹。

> 路径约定：本文中的 `<本技能目录>` 指本 SKILL.md 所在目录（即 `.../weekly-report-full/skills/weekly-report-full`）。本技能自包含，所有脚本都在 `scripts/` 下，不依赖其它 skill。

## 交付目标（四张图）

| 文件 | 来源 sheet | 内容 |
|---|---|---|
| 周报.png | 3-有运营物料season转化 | 带条件格式高亮的周报可视化图 |
| 动画.png | 4-动画物料枚举 | 动画 TOP&BOTTOM case 列表图 |
| 影剧综.png | 5-影剧综物料枚举 | 影剧综 TOP&BOTTOM case 列表图 |
| 纪录片.png | 6-纪录片物料枚举 | 纪录片 TOP&BOTTOM case 列表图 |

## 工作流程（严格按顺序执行）

### 1. 定位 Excel 文件路径

从用户消息的附件或提到路径中找到 xlsx 的绝对路径。

### 2. 创建工作目录并生成四个 HTML

用 Bitto 内置 Python（`$env:BITTO_PYTHON_BIN`），把四个 HTML 都输出到同一个工作目录 `<Excel同目录>\.weekly_report_full\`：

```powershell
& $env:BITTO_PYTHON_BIN "<本技能目录>/scripts/report/generate_report.py" "<excel绝对路径>" "<工作目录>"
& $env:BITTO_PYTHON_BIN "<本技能目录>/scripts/list/generate_list.py" "<excel绝对路径>" "<工作目录>"
```

- 第一个脚本生成 `report.html`（周报，13 列）
- 第二个脚本生成 `list_0.html` / `list_1.html` / `list_2.html`（对应 动画 / 影剧综 / 纪录片）

### 3. 起本地 HTTP 服务 serve 工作目录

```powershell
cd "<工作目录>"; & $env:BITTO_PYTHON_BIN -m http.server 8765 --bind 127.0.0.1
```

（lifetime=session、tty=true）

### 4. 起保存服务器

```powershell
& $env:BITTO_PYTHON_BIN "<本技能目录>/scripts/save_all.py" "<工作目录>" 8766
```

（lifetime=session、tty=true）

### 5. 浏览器打开四个 HTML 并导出 PNG

依次对下面四个页面：用 browser.open 打开（URL 加缓存破坏参数 `?v=<时间戳>`），用 browser.eval 确认 `window.__REPORT_PNG` 已生成（字符串、长度几十万到上百万），再用 browser.eval 执行 fetch POST 保存：

| HTML | 保存 fetch URL |
|---|---|
| report.html | /save/周报.png |
| list_0.html | /save/动画.png |
| list_1.html | /save/影剧综.png |
| list_2.html | /save/纪录片.png |

```js
fetch('http://127.0.0.1:8766/save/周报.png', {method:'POST', body: window.__REPORT_PNG}).then(r=>r.text()).then(t=>'SAVED:'+t)
```

每张确认返回 `SAVED:ok`。

### 6. 验证并交付

- 确认四张 PNG 存在、大小正常（几百 KB~1MB+）、PNG 签名 `89 50 4E 47`
- 建议用视觉能力（bitto-vision）抽查：表头中文无乱码、数值与 Excel 一致、条件格式方向正确、封面缩略图正常
- 关闭两个后台服务器
- 把四张 PNG 复制到 `<Excel同目录>\周报全套_<周期>\`（周期从 Excel 文件名提取，如 0910-0916），向用户说明路径

## 关键约束

- 数值必须与 Excel 完全一致，不可编造；空值显示"—"并留灰
- 周报图配色在 `scripts/report/colors.json`；列表图配色在 `scripts/list/colors.json`
- 本技能自包含：脚本分别在 `scripts/report/`、`scripts/list/`、`scripts/save_all.py`，勿改回引用其它 skill 的绝对路径
- 浏览器缓存旧 HTML：必须用 cache-busting URL（`?v=1`、`?v=2`…）强制刷新
- 写文件用 `[System.IO.File]::WriteAllText($dest, $content, (New-Object System.Text.UTF8Encoding($false)))` 避免 BOM