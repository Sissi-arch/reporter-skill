#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
物料中台周报可视化生成脚本
用法: python generate_report.py <excel_path> [output_dir]

功能:
1. 解析物料中台周报 Excel 的「3-有运营物料season转化」sheet
2. 按 scripts/colors.json 的配色计算条件格式(红色数据条/正负绿红/红蓝色阶)
3. 生成一个 Canvas 渲染的 HTML 文件, 供浏览器渲染成 PNG

输出:
- <output_dir>/report.html      渲染入口(供浏览器打开)
- <output_dir>/report_data.json 中间数据(调试用)
"""

import zipfile
import xml.etree.ElementTree as ET
import json
import os
import re
import sys

# ==================== 默认颜色配置(colors.json 缺失或解析失败时使用) ====================
DEFAULT_COLORS = {
    "table": {
        "header_bg": "#f0f1f3",
        "header_text": "#222222",
        "zebra_stripe": "#fafafa",
        "normal_text": "#1a1a1a",
        "title_text": "#111111",
        "subtitle_text": "#666666",
        "footnote_text": "#888888"
    },
    "data_bars": {
        "numeric": {"color": [216, 30, 30], "min_alpha": 0.16, "max_alpha": 0.56},
        "change_positive": {"color": [10, 160, 70], "alpha": 0.30},
        "change_negative": {"color": [210, 45, 45], "alpha": 0.30}
    },
    "change_text": {
        "positive": "#0a8f3c",
        "negative": "#c62828",
        "empty": "#9aa0a6"
    },
    "blue_bar": {
        "color": [125, 161, 208],
        "min_alpha": 0.20,
        "max_alpha": 0.70
    },
    "ctr_red_bg": {
        "low": [255, 255, 255],
        "high": [250, 170, 173]
    },
    "change_bg": {
        "green": "#8BCF9E",
        "red": "#FAAAAD",
        "yellow": "#FFEC85",
        "yellow_threshold": 0.05,
        "text": "#1a1a1a"
    },
    "color_scale": {
        "low": [214, 234, 248],
        "mid": [255, 255, 255],
        "high": [250, 219, 216]
    },
    "blue_scale": {
        "low": [255, 255, 255],
        "high": [92, 156, 213]
    },
    "category_tags": {
        "番剧": {"bg": "#FDEBD0", "text": "#B9770E"},
        "国创": {"bg": "#E8F8E0", "text": "#1E8449"},
        "电影": {"bg": "#D6EAF8", "text": "#1F618D"},
        "电视剧": {"bg": "#EBDEF0", "text": "#6C3483"},
        "纪录片": {"bg": "#D5F5E3", "text": "#148F77"},
        "综艺": {"bg": "#FADBD8", "text": "#B03A2E"},
        "赛事": {"bg": "#D1F2EB", "text": "#117864"},
        "微短剧": {"bg": "#EAECEE", "text": "#5D6D7E"},
        "默认": {"bg": "#FFFFFF", "text": "#000000"}
    }
}

# ==================== 列定义: (表头名, 内部key, 显示类型, 对齐, 条件格式规则) ====================
# 显示类型: text/int/pct/float/chg_pct/chg_int/chg_float
# 规则: bar_numeric=红色数据条; change=正负绿红; scale=红蓝色阶
COLUMN_DEFS = [
    ("品类",            "category",      "text",      "left",  None),
    ("剧集名称",        "name",          "text",      "left",  None),
    ("season_id",       "season_id",     "text",      "left",  None),
    ("近两周运营物料数量", "material_count", "int",       "right", None),
    ("曝光pv",          "pv",            "int",       "right", "bar_numeric"),
    ("CTR",             "ctr",           "pct",       "right", "scale"),
    ("CTR变化",         "ctr_chg",       "chg_pct",   "right", "change"),
    ("10sCVR",          "cvr",           "pct",       "right", "scale"),
    ("CVR变化",         "cvr_chg",       "chg_pct",   "right", "change"),
    ("天马主动GMV",      "gmv",           "int",       "right", "bar_numeric"),
    ("GMV变化",         "gmv_chg",       "chg_int",   "right", "change"),
    ("主动ECPM",        "ecpm",          "float",     "right", "scale_blue"),
    ("ECPM变化",        "ecpm_chg",      "chg_float", "right", "change"),
]

COL_WIDTHS = {
    "category": 64, "name": 236, "season_id": 82, "material_count": 84,
    "pv": 110, "ctr": 74, "ctr_chg": 86, "cvr": 74, "cvr_chg": 86,
    "gmv": 100, "gmv_chg": 94, "ecpm": 78, "ecpm_chg": 86,
}

# ==================== 工具函数 ====================
def load_colors(script_dir):
    """读取 colors.json, 深度合并到默认配色(递归合并所有键)"""
    colors = json.loads(json.dumps(DEFAULT_COLORS))  # 深拷贝
    cfg = os.path.join(script_dir, "colors.json")
    if os.path.exists(cfg):
        try:
            with open(cfg, "r", encoding="utf-8") as f:
                user = json.load(f)

            def _merge(dst, src):
                for k, v in src.items():
                    if k in dst and isinstance(dst[k], dict) and isinstance(v, dict):
                        _merge(dst[k], v)
                    else:
                        dst[k] = v

            _merge(colors, user)
        except Exception as e:
            print("警告: colors.json 解析失败, 使用默认配色: %s" % e, file=sys.stderr)
    return colors

def tof(v):
    if v is None:
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None

def fmt_int(v):
    f = tof(v)
    return "%s" % format(int(round(f)), ",") if f is not None else ""

def fmt_pct(v):
    f = tof(v)
    return "%.2f%%" % (f * 100) if f is not None else ""

def fmt_float(v):
    f = tof(v)
    return "%.2f" % f if f is not None else ""

def fmt_chg(v, kind):
    f = tof(v)
    if f is None:
        return "—"
    if f == 0:
        return "0.00%" if kind == "pct" else ("0" if kind == "int" else "0.00")
    if kind == "pct":
        return "%+.2f%%" % (f * 100)
    if kind == "int":
        return "%+.0f" % f
    return "%+.2f" % f

def rgba(color, alpha):
    r, g, b = color
    return "rgba(%d,%d,%d,%.3f)" % (r, g, b, alpha)

def _interp(a, b, s):
    return [round(a[i] * (1 - s) + b[i] * s) for i in range(3)]

def lerp_color(t, low, mid, high):
    """三色色阶: t=0->low(蓝), t=0.5->mid(白), t=1->high(红)"""
    if t <= 0.5:
        s = t / 0.5
        rgb = _interp(low, mid, s)
    else:
        s = (t - 0.5) / 0.5
        rgb = _interp(mid, high, s)
    return "rgb(%d,%d,%d)" % tuple(rgb)

def wrap(text, n):
    out = []
    while len(text) > n:
        out.append(text[:n])
        text = text[n:]
    if text:
        out.append(text)
    return out

# ==================== xlsx 解析(纯标准库, 支持 sharedStrings / inlineStr) ====================
def parse_xlsx(path):
    M = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    R_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    def tag(t):
        return t.split("}", 1)[1] if "}" in t else t
    def coltext(node):
        return "".join(x.text or "" for x in node.iter() if tag(x.tag) == "t")

    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        ss = []
        if "xl/sharedStrings.xml" in names:
            with z.open("xl/sharedStrings.xml") as f:
                root = ET.parse(f).getroot()
                for si in root:
                    ss.append(coltext(si))
        # workbook -> sheets
        with z.open("xl/workbook.xml") as f:
            wb = ET.parse(f).getroot()
        sheets = []
        for s in wb.iter():
            if tag(s.tag) == "sheet":
                sheets.append((s.attrib.get("name"), s.attrib.get(R_NS + "id")))
        # 找第三部分 sheet: 名以 "3-" 开头, 或含 "season"/"转化"
        target = None
        for name, rid in sheets:
            if name.startswith("3-"):
                target = (name, rid); break
        if target is None:
            for name, rid in sheets:
                if "转化" in name or "season" in name.lower():
                    target = (name, rid); break
        if target is None:
            raise SystemExit("未找到「3-有运营物料season转化」sheet, 可用 sheet: %s" % [n for n, _ in sheets])
        # rels -> sheet 文件路径
        with z.open("xl/_rels/workbook.xml.rels") as f:
            rels = ET.parse(f).getroot()
        rid_to_target = {r.attrib["Id"]: r.attrib["Target"] for r in rels}
        sheet_file = rid_to_target[target[1]]
        if not sheet_file.startswith("xl/"):
            sheet_file = "xl/" + sheet_file.lstrip("/")
        sheet_file = sheet_file.replace("xl/xl/", "xl/")
        # 解析 sheet
        with z.open(sheet_file) as f:
            root = ET.parse(f).getroot()
        rows = []
        for row in root.iter():
            if tag(row.tag) != "row":
                continue
            cells = {}
            for c in row:
                if tag(c.tag) != "c":
                    continue
                ref = c.attrib.get("r", "")
                t = c.attrib.get("t")
                v = None
                for child in c:
                    ct = tag(child.tag)
                    if ct == "v":
                        v = child.text
                    elif ct == "is":
                        v = coltext(child)
                if t == "s" and v is not None and v.lstrip("-").isdigit():
                    v = ss[int(v)]
                cells[ref] = v
            rows.append(cells)

    def ref_to_col(ref):
        letters = "".join(ch for ch in ref if ch.isalpha())
        idx = 0
        for ch in letters:
            idx = idx * 26 + (ord(ch) - ord("A") + 1)
        return idx - 1

    max_col = 0
    for row in rows:
        for ref in row:
            ci = ref_to_col(ref)
            if ci > max_col:
                max_col = ci
    matrix = []
    for row in rows:
        vals = [None] * (max_col + 1)
        for ref, v in row.items():
            ci = ref_to_col(ref)
            if 0 <= ci <= max_col:
                vals[ci] = v
        matrix.append(vals)

    note = ""
    header = []
    data = []
    if matrix:
        for v in matrix[0]:
            if v:
                note = v
                break
    if len(matrix) >= 2:
        header = [v if v is not None else "" for v in matrix[1]]
    for row in matrix[2:]:
        data.append(row)
    return note, header, data

# ==================== 主流程 ====================
def main():
    if len(sys.argv) < 2:
        print("用法: python generate_report.py <excel_path> [output_dir]")
        sys.exit(1)
    excel = sys.argv[1]
    if not os.path.exists(excel):
        raise SystemExit("Excel 文件不存在: %s" % excel)
    out_dir = sys.argv[2] if len(sys.argv) > 2 else os.path.join(
        os.path.dirname(os.path.abspath(excel)), ".weekly_report")
    os.makedirs(out_dir, exist_ok=True)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    colors = load_colors(script_dir)

    note, header, data = parse_xlsx(excel)

    # 表头名 -> 列索引
    col_index = {}
    for i, h in enumerate(header):
        key = (h or "").strip()
        col_index[key] = i

    # 按 COLUMN_DEFS 建立有效列
    active_cols = []
    for name, key, typ, align, rule in COLUMN_DEFS:
        idx = col_index.get(name)
        if idx is None:
            # 尝试宽松匹配(去掉空格)
            idx = col_index.get(name.replace(" ", ""))
        if idx is None:
            continue  # 该列在本次 Excel 中不存在, 跳过
        active_cols.append({"name": name, "key": key, "type": typ,
                            "align": align, "rule": rule, "idx": idx,
                            "w": COL_WIDTHS.get(key, 80)})

    # 数据行清洗: 品类继承上一行(处理合并单元格), 跳过全空行
    rows_clean = []
    last_cat = None
    cat_idx = None
    for ac in active_cols:
        if ac["key"] == "category":
            cat_idx = ac["idx"]
    for row in data:
        if all(v is None or (isinstance(v, str) and not v.strip()) for v in row):
            continue
        if cat_idx is not None:
            cv = row[cat_idx] if cat_idx < len(row) else None
            if cv is None or (isinstance(cv, str) and not cv.strip()):
                if cat_idx < len(row):
                    row[cat_idx] = last_cat
            elif cv:
                last_cat = cv
        rows_clean.append(row)

    # 计算条件格式
    def col_vals(key):
        idxs = [ac["idx"] for ac in active_cols if ac["key"] == key]
        if not idxs:
            return []
        i = idxs[0]
        return [tof(r[i]) if i < len(r) else None for r in rows_clean]

    def col_max(key):
        vs = [v for v in col_vals(key) if v is not None]
        return max(vs) if vs else 0
    def col_minmax(key):
        vs = [v for v in col_vals(key) if v is not None]
        return (min(vs), max(vs)) if vs else (0, 0)
    def col_max_abs(key):
        vs = [abs(v) for v in col_vals(key) if v is not None]
        return max(vs) if vs else 1.0

    max_pv = col_max("pv")
    max_gmv = col_max("gmv")
    max_chg = {"ctr_chg": col_max_abs("ctr_chg"), "cvr_chg": col_max_abs("cvr_chg"),
               "gmv_chg": col_max_abs("gmv_chg"), "ecpm_chg": col_max_abs("ecpm_chg")}
    mm = {"ctr": col_minmax("ctr"), "cvr": col_minmax("cvr"), "ecpm": col_minmax("ecpm")}

    ct = colors["change_text"]
    tags = colors["category_tags"]

    render = []
    for row in rows_clean:
        cells = []
        for ac in active_cols:
            raw = row[ac["idx"]] if ac["idx"] < len(row) else None
            typ = ac["type"]
            cell = {"align": ac["align"], "text": "", "bg": None,
                    "fg": colors["table"]["normal_text"], "bar": None, "barPct": 0}
            # 文本
            if typ == "text":
                cell["text"] = raw if raw is not None else ""
                if ac["key"] == "category":
                    tag_cfg = tags.get(raw, tags.get("默认", {"bg": "#FFFFFF", "text": "#000000"}))
                    cell["bg"] = tag_cfg.get("bg", "#FFFFFF")
                    cell["fg"] = tag_cfg.get("text", "#000000")
            elif typ == "int":
                cell["text"] = fmt_int(raw)
            elif typ == "pct":
                cell["text"] = fmt_pct(raw)
            elif typ == "float":
                cell["text"] = fmt_float(raw)
            elif typ == "chg_pct":
                cell["text"] = fmt_chg(raw, "pct")
            elif typ == "chg_int":
                cell["text"] = fmt_chg(raw, "int")
            elif typ == "chg_float":
                cell["text"] = fmt_chg(raw, "float")
            # 规则: 红色数据条
            if ac["rule"] == "bar_numeric":
                f = tof(raw)
                if f is not None:
                    m = col_max(ac["key"])
                    pct = f / m if m > 0 else 0
                    db = colors["data_bars"]["numeric"]
                    alpha = db["min_alpha"] + (db["max_alpha"] - db["min_alpha"]) * pct
                    cell["bar"] = rgba(db["color"], alpha)
                    cell["barPct"] = pct * 100
            # 规则: 正绿底/负红底(整格底色)
            if ac["rule"] == "change":
                f = tof(raw)
                if f is None:
                    cell["fg"] = ct["empty"]
                    cell["text"] = "\u2014"
                else:
                    cs = colors["change_scale"]
                    m = max_chg.get(ac["key"], 1.0)
                    t = (abs(f) / m) if m > 0 else 0.0
                    if f > 0:
                        rgb = _interp(cs["zero"], cs["positive"], t)
                        cell["bg"] = "rgb(%d,%d,%d)" % tuple(rgb)
                        lum = 0.299*rgb[0] + 0.587*rgb[1] + 0.114*rgb[2]
                        cell["fg"] = "#ffffff" if lum < 128 else ct["positive"]
                    elif f < 0:
                        rgb = _interp(cs["zero"], cs["negative"], t)
                        cell["bg"] = "rgb(%d,%d,%d)" % tuple(rgb)
                        lum = 0.299*rgb[0] + 0.587*rgb[1] + 0.114*rgb[2]
                        cell["fg"] = "#ffffff" if lum < 128 else ct["negative"]
                    else:
                        cell["bg"] = None
                        cell["fg"] = colors["table"]["normal_text"]
            # 规则: 红蓝色阶
            if ac["rule"] == "scale":
                f = tof(raw)
                if f is not None:
                    lo, hi = mm.get(ac["key"], (0, 0))
                    t = (f - lo) / (hi - lo) if hi > lo else 0.5
                    cs = colors["color_scale"]
                    cell["bg"] = lerp_color(t, cs["low"], cs["mid"], cs["high"])
                    cell["fg"] = "#1a1a1a"
            # 规则: 蓝色单色阶(白->蓝, 大偏蓝)
            if ac["rule"] == "scale_blue":
                f = tof(raw)
                if f is not None:
                    lo, hi = mm.get(ac["key"], (0, 0))
                    t = (f - lo) / (hi - lo) if hi > lo else 0.5
                    bs = colors["blue_scale"]
                    rgb = _interp(bs["low"], bs["high"], t)
                    cell["bg"] = "rgb(%d,%d,%d)" % tuple(rgb)
                    cell["fg"] = "#1a1a1a"
            cells.append(cell)
        render.append(cells)

    # 周期(从文件名提取 0910-0916)
    base = os.path.basename(excel)
    m = re.search(r"(\d{4})-(\d{4})", base)
    period = "%s — %s" % (m.group(1), m.group(2)) if m else ""

    note_lines = wrap(note, 88)
    payload = {
        "table": colors["table"],
        "cols": [{"name": ac["name"], "w": ac["w"]} for ac in active_cols],
        "render": render,
        "note": note_lines,
        "period": period,
    }

    # 生成 HTML
    html = _build_html(payload)
    html_path = os.path.join(out_dir, "report.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    data_path = os.path.join(out_dir, "report_data.json")
    with open(data_path, "w", encoding="utf-8") as f:
        json.dump({"note": note, "header": [ac["name"] for ac in active_cols],
                   "rows": len(rows_clean), "period": period}, f, ensure_ascii=False)

    print("HTML 已生成: %s" % html_path)
    print("数据行数: %d, 列数: %d" % (len(rows_clean), len(active_cols)))
    print("周期: %s" % period)

def _build_html(payload):
    json_str = json.dumps(payload, ensure_ascii=False)
    return """<!DOCTYPE html><html><head><meta charset="utf-8"><title>周报</title></head><body>
<div id="d" style="display:none">""" + json_str + """</div><canvas id="cv"></canvas>
<script>
var P = JSON.parse(document.getElementById('d').textContent);
var T = P.table;
var cols = P.cols, render = P.render, note = P.note, period = P.period;
var HEADER_H = 40, ROW_H = 25, TITLE_H = 50, SUB_H = 22, FOOT_H = 14, PAD_TOP = 18;
var totalW = 0; cols.forEach(function(c){totalW+=c.w;});
var nrows = render.length;
var totalH = PAD_TOP + TITLE_H + SUB_H + 10 + HEADER_H + nrows*ROW_H + 8 + FOOT_H*note.length + 20;
var SCALE = 2;
var cv = document.getElementById('cv');
cv.width = totalW*SCALE; cv.height = totalH*SCALE;
cv.style.width = totalW+'px'; cv.style.height = totalH+'px';
var ctx = cv.getContext('2d');
ctx.scale(SCALE, SCALE);
ctx.font = '14px SimHei, "Microsoft YaHei", sans-serif';
ctx.textBaseline = 'middle';
function text(s,x,y,align,font,color){
  ctx.font = font; ctx.fillStyle = color; ctx.textAlign = align;
  ctx.fillText(s, x, y);
}
ctx.fillStyle = '#ffffff'; ctx.fillRect(0,0,totalW,totalH);
text('有运营物料 Season 转化周报', totalW/2, PAD_TOP+TITLE_H/2, 'center', 'bold 21px SimHei, "Microsoft YaHei", sans-serif', T.title_text);
var sub = '数据周期 ' + period;
text(sub, totalW/2, PAD_TOP+TITLE_H+SUB_H/2, 'center', '12px SimHei, "Microsoft YaHei", sans-serif', T.subtitle_text);
var ty = PAD_TOP + TITLE_H + SUB_H + 10;
var x = 0;
for (var i=0;i<cols.length;i++){
  var c = cols[i];
  ctx.fillStyle = T.header_bg;
  ctx.fillRect(x, ty, c.w, HEADER_H);
  text(c.name, x+c.w/2, ty+HEADER_H/2, 'center', 'bold 13px SimHei, "Microsoft YaHei", sans-serif', T.header_text);
  x += c.w;
}
ty += HEADER_H;
for (var ri=0;ri<nrows;ri++){
  var row = render[ri];
  var x = 0;
  for (var ci=0;ci<cols.length;ci++){
    var c = cols[ci]; var cell = row[ci];
    if (cell.bg){ ctx.fillStyle = cell.bg; ctx.fillRect(x, ty, c.w, ROW_H); }
    else { ctx.fillStyle = '#ffffff'; ctx.fillRect(x, ty, c.w, ROW_H); }
    if (!cell.bg && ri%2===1){ ctx.fillStyle=T.zebra_stripe; ctx.fillRect(x, ty, c.w, ROW_H); }
    if (cell.bar){
      var bw = Math.max(0, c.w * cell.barPct/100);
      if (bw > 0){ ctx.fillStyle = cell.bar; ctx.fillRect(x, ty+2, bw, ROW_H-4); }
    }
    var tx = cell.align==='right' ? x+c.w-8 : x+8;
    text(cell.text, tx, ty+ROW_H/2, cell.align, '12px SimHei, "Microsoft YaHei", sans-serif', cell.fg);
    x += c.w;
  }
  ty += ROW_H;
}
ty += 8;
for (var k=0;k<note.length;k++){
  text(note[k], 4, ty+FOOT_H/2, 'left', '10px SimHei, "Microsoft YaHei", sans-serif', T.footnote_text);
  ty += FOOT_H;
}
window.__REPORT_PNG = cv.toDataURL('image/png');
document.title = 'DONE';
</script></body></html>"""

if __name__ == "__main__":
    main()