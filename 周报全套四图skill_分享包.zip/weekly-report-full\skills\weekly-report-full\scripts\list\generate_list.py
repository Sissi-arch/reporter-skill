#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TOP&BOTTOM case 列表图生成脚本
用法: python generate_list.py <excel_path> [output_dir]

功能:
1. 解析 Excel 的「4-动画物料枚举」「5-影剧综物料枚举」「6-纪录片物料枚举」三个 sheet
2. 下载物料封面缩略图到本地 images/ 目录
3. 为每个 sheet 生成一个 Canvas 渲染的 HTML 列表图
   (品类列第一列纵向合并, 类别列 Top/Bottom 纵向合并, 图片缩略图, 有效vt/曝光双行)

输出:
- <output_dir>/list_0.html(list_1/list_2)  渲染入口
- <output_dir>/images/*.webp               封面缩略图
- <output_dir>/list_data.json              中间数据
"""

import zipfile
import xml.etree.ElementTree as ET
import json
import os
import re
import sys
import urllib.request

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# ==================== 大类名映射 ====================
CATEGORY_MAP = {"4": "动画", "5": "影剧综", "6": "纪录片"}

# ==================== 列定义 ====================
# (表头名, key, 类型, 对齐)  类型: merge(合并列) / text / image / dual(双行)
COLUMNS = [
    ("品类",        "category",     "merge", "center"),
    ("类别",        "rank_group",   "merge", "center"),
    ("物料id",      "mid",          "text",  "left"),
    ("图片",        "image",        "image", "center"),
    ("title",       "title",        "text",  "left"),
    ("描述",        "desc",         "text",  "left"),
    ("曝光pv",      "pv",           "int",   "left"),
    ("CTR",         "ctr",          "pct",   "left"),
    ("有效vt/曝光", "vt_exposure",  "dual",  "left"),
    ("GMV",         "gmv",          "int",   "left"),
]

WRAP_CAP = {"title": 200, "desc": 180}

DEFAULT_COLORS = {
    "font_family": 'SimHei, "Microsoft YaHei", sans-serif',
    "font_size": 13,
    "font_size_header": 13,
    "font_size_note": 11,
    "header_bg": None,
    "header_text": "#1a1a1a",
    "normal_text": "#333333",
    "note_text": "#888888",
    "border": "#D9D9D9",
    "image_size": 100,
    "image_w": 178,
    "line_height": 20,
    "cell_pad_x": 8,
    "cell_pad_y": 6,
    "header_height": 30,
    "scale": 2,
}

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
REFERER = "https://www.bilibili.com/"


def load_colors():
    colors = json.loads(json.dumps(DEFAULT_COLORS))
    cfg = os.path.join(SCRIPT_DIR, "colors.json")
    if os.path.exists(cfg):
        try:
            with open(cfg, "r", encoding="utf-8") as f:
                user = json.load(f)
            def _merge(dst, src):
                for k, v in src.items():
                    if k in dst and isinstance(dst[k], dict) and isinstance(v, dict):
                        _merge(dst[k], v)
                    else:
                        dst[k] = v
            _merge(colors, user)
        except Exception as e:
            print("警告: colors.json 解析失败: %s" % e, file=sys.stderr)
    return colors


def tof(v):
    if v is None:
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def fmt_int(v):
    f = tof(v)
    return "%s" % format(int(round(f)), ",") if f is not None else ""


def fmt_pct(v):
    f = tof(v)
    return "%.2f%%" % (f * 100) if f is not None else ""


def fmt_float(v):
    f = tof(v)
    return "%.2f" % f if f is not None else ""


def parse_xlsx(path):
    M = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    R_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    def tag(t):
        return t.split("}", 1)[1] if "}" in t else t
    def coltext(node):
        return "".join(x.text or "" for x in node.iter() if tag(x.tag) == "t")

    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        ss = []
        if "xl/sharedStrings.xml" in names:
            with z.open("xl/sharedStrings.xml") as f:
                root = ET.parse(f).getroot()
                for si in root:
                    ss.append(coltext(si))
        with z.open("xl/workbook.xml") as f:
            wb = ET.parse(f).getroot()
        sheets = []
        for s in wb.iter():
            if tag(s.tag) == "sheet":
                sheets.append((s.attrib.get("name"), s.attrib.get(R_NS + "id")))
        with z.open("xl/_rels/workbook.xml.rels") as f:
            rels = ET.parse(f).getroot()
        rid_to_target = {r.attrib["Id"]: r.attrib["Target"] for r in rels}

        def ref_to_col(ref):
            letters = "".join(ch for ch in ref if ch.isalpha())
            idx = 0
            for ch in letters:
                idx = idx * 26 + (ord(ch) - ord("A") + 1)
            return idx - 1

        def parse_sheet(rid):
            target = rid_to_target[rid]
            if not target.startswith("xl/"):
                target = "xl/" + target.lstrip("/")
            target = target.replace("xl/xl/", "xl/")
            with z.open(target) as f:
                root = ET.parse(f).getroot()
            rows = []
            for row in root.iter():
                if tag(row.tag) != "row":
                    continue
                cells = {}
                for c in row:
                    if tag(c.tag) != "c":
                        continue
                    ref = c.attrib.get("r", "")
                    t = c.attrib.get("t")
                    v = None
                    for child in c:
                        ct = tag(child.tag)
                        if ct == "v":
                            v = child.text
                        elif ct == "is":
                            v = coltext(child)
                    if t == "s" and v is not None and v.lstrip("-").isdigit():
                        v = ss[int(v)]
                    cells[ref] = v
                rows.append(cells)
            max_col = 0
            for row in rows:
                for ref in row:
                    ci = ref_to_col(ref)
                    if ci > max_col:
                        max_col = ci
            matrix = []
            for row in rows:
                vals = [None] * (max_col + 1)
                for ref, v in row.items():
                    ci = ref_to_col(ref)
                    if 0 <= ci <= max_col:
                        vals[ci] = v
                matrix.append(vals)
            return matrix

        result = {}
        for name, rid in sheets:
            if name.startswith(("4-", "5-", "6-")) or "物料枚举" in name:
                result[name] = parse_sheet(rid)
        if not result:
            raise SystemExit("未找到物料枚举 sheet: %s" % [n for n, _ in sheets])
        return result


def thumb_url(url):
    if not url:
        return None
    return url + "@320w_180h.webp"


def download(url, dest):
    if not url:
        return False
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": REFERER})
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = resp.read()
        if not data:
            return False
        with open(dest, "wb") as f:
            f.write(data)
        return True
    except Exception as e:
        print("  下载失败 %s -> %s" % (url[-40:], e), file=sys.stderr)
        return False


def category_from_sheet(name):
    for kw in ("动画", "影剧综", "纪录片"):
        if kw in name:
            return kw
    return name


def main():
    if len(sys.argv) < 2:
        print("用法: python generate_list.py <excel_path> [output_dir]")
        sys.exit(1)
    excel = sys.argv[1]
    if not os.path.exists(excel):
        raise SystemExit("Excel 文件不存在: %s" % excel)
    out_dir = sys.argv[2] if len(sys.argv) > 2 else os.path.join(
        os.path.dirname(os.path.abspath(excel)), ".top_bottom_case")
    img_dir = os.path.join(out_dir, "images")
    os.makedirs(img_dir, exist_ok=True)

    colors = load_colors()
    sheets = parse_xlsx(excel)

    payloads = []
    for sheet_idx, name in enumerate(sorted(sheets.keys())):
        matrix = sheets[name]

        # 找表头行(含"品类"或"榜位"或"类别")
        header_idx = None
        for i, row in enumerate(matrix):
            for v in row:
                if v and str(v).strip() in ("品类", "榜位", "类别"):
                    header_idx = i
                    break
            if header_idx is not None:
                break
        if header_idx is None:
            header_idx = 1

        # note = 表头前的第一个非空单元格
        note = ""
        for i in range(header_idx):
            for v in matrix[i]:
                if v:
                    note = str(v)
                    break

        header = [v if v is not None else "" for v in matrix[header_idx]]
        data = matrix[header_idx + 1:]

        def find_col(keywords):
            for i, h in enumerate(header):
                hs = (h or "").strip()
                for kw in keywords:
                    if kw.lower() in hs.lower():
                        return i
            return None

        idx_rank = find_col(["榜位"])
        idx_rank_group = find_col(["类别"])
        idx_threshold = find_col(["曝光门槛"])
        idx_mid = find_col(["物料id"])
        idx_img = find_col(["图片"])
        idx_title = find_col(["title"])
        idx_desc = find_col(["描述"])
        idx_pv = find_col(["曝光pv"])
        idx_ctr = find_col(["CTR"])
        idx_vt = find_col(["有效vt"])
        idx_gmv = find_col(["GMV"])

        rows_clean = []
        for row in data:
            if all(v is None or (isinstance(v, str) and not v.strip()) for v in row):
                continue
            rows_clean.append(row)

        category = category_from_sheet(name)
        render_rows = []
        for ri, row in enumerate(rows_clean):
            def g(idx):
                return row[idx] if idx is not None and idx < len(row) else None
            rank_raw = g(idx_rank) or ""
            if rank_raw:
                rank_group = "Top" if str(rank_raw).upper().startswith("TOP") else ("Bottom" if str(rank_raw).upper().startswith("BOTTOM") else "")
            else:
                rank_group = g(idx_rank_group) or ""

            # 图片下载
            img_url = g(idx_img)
            local = None
            if img_url:
                fname = "img_%d_%d.webp" % (sheet_idx, ri)
                dest = os.path.join(img_dir, fname)
                if download(thumb_url(img_url), dest):
                    local = "images/" + fname
                else:
                    ext = ".png" if img_url.lower().endswith(".png") else ".jpg"
                    fname = "img_%d_%d%s" % (sheet_idx, ri, ext)
                    dest = os.path.join(img_dir, fname)
                    if download(img_url, dest):
                        local = "images/" + fname

            render_rows.append({
                "rank_group": rank_group,
                "mid": g(idx_mid) if g(idx_mid) is not None else "",
                "image": local,
                "title": g(idx_title) if g(idx_title) is not None else "",
                "desc": g(idx_desc) if g(idx_desc) is not None else "",
                "pv": fmt_int(g(idx_pv)),
                "ctr": fmt_pct(g(idx_ctr)),
                "vt": fmt_float(g(idx_vt)),
                "exposure": g(idx_threshold) if g(idx_threshold) is not None else "",
                "gmv": fmt_int(g(idx_gmv)),
            })

        payloads.append({
            "note": note,
            "category": category,
            "output_name": category + ".png",
            "sheet": name,
            "cols": [{"name": c[0], "key": c[1], "type": c[2], "align": c[3]} for c in COLUMNS],
            "rows": render_rows,
            "wrap_cap": WRAP_CAP,
        })

    html_paths = []
    for i, payload in enumerate(payloads):
        html = build_html(payload, colors)
        hp = os.path.join(out_dir, "list_%d.html" % i)
        with open(hp, "w", encoding="utf-8") as f:
            f.write(html)
        html_paths.append(hp)

    with open(os.path.join(out_dir, "list_data.json"), "w", encoding="utf-8") as f:
        json.dump({"payloads": payloads}, f, ensure_ascii=False, indent=1)

    print("生成 %d 张列表图 HTML:" % len(html_paths))
    for i, pl in enumerate(payloads):
        print("  list_%d.html  ->  %s" % (i, pl["output_name"]))
    print("缩略图目录: %s" % img_dir)


def build_html(payload, colors):
    cfg = {
        "font": colors["font_family"],
        "fs": colors["font_size"],
        "fs_h": colors["font_size_header"],
        "fs_note": colors["font_size_note"],
        "header_bg": colors["header_bg"],
        "header_text": colors["header_text"],
        "normal_text": colors["normal_text"],
        "note_text": colors["note_text"],
        "border": colors["border"],
        "img": colors["image_size"],
        "img_w": colors["image_w"],
        "lh": colors["line_height"],
        "padx": colors["cell_pad_x"],
        "pady": colors["cell_pad_y"],
        "header_h": colors["header_height"],
        "scale": colors["scale"],
    }
    payload["cfg"] = cfg
    json_str = json.dumps(payload, ensure_ascii=False)
    return _HTML_HEAD + json_str + _HTML_TAIL


_HTML_HEAD = """<!DOCTYPE html><html><head><meta charset="utf-8"><title>TOP&BOTTOM case</title></head><body>
<div id="d" style="display:none">"""

_HTML_TAIL = """</div><canvas id="cv"></canvas>
<script>
var P = JSON.parse(document.getElementById('d').textContent);
var C = P.cfg;
var cols = P.cols, rows = P.rows, note = P.note, wrapCap = P.wrap_cap;
var CATEGORY = P.category;
var FONT = C.fs+'px '+C.font;
var SCALE = C.scale;
var PADX = C.padx, PADY = C.pady, LH = C.lh, IMG = C.img, IMG_W = C.img_w, HEADER_H = C.header_h;

var mctx = document.createElement('canvas').getContext('2d');
mctx.font = FONT;

function wrap(text, maxW){
  if(!text) return [''];
  var lines=[], cur='';
  for(var i=0;i<text.length;i++){
    var t=cur+text[i];
    if(mctx.measureText(t).width > maxW && cur){ lines.push(cur); cur=text[i]; }
    else cur=t;
  }
  if(cur) lines.push(cur);
  return lines;
}

// 计算列宽
var colW = [];
for(var ci=0; ci<cols.length; ci++){
  var col = cols[ci];
  var w = mctx.measureText(col.name).width;
  var cap = wrapCap[col.key] || Infinity;
  if(col.type==='merge'){
    if(col.key==='category') w = Math.max(w, mctx.measureText(CATEGORY).width);
    if(col.key==='rank_group') w = Math.max(w, mctx.measureText('Top').width, mctx.measureText('Bottom').width);
  } else if(col.type==='dual'){
    for(var ri=0; ri<rows.length; ri++){
      w = Math.max(w, mctx.measureText(rows[ri].vt).width);
    }
  } else if(col.type==='image'){
    w = 0;
  } else {
    for(var ri=0; ri<rows.length; ri++){
      var v = rows[ri][col.key];
      if(v===null || v===undefined) v='';
      w = Math.max(w, Math.min(mctx.measureText(String(v)).width, cap));
    }
  }
  colW[ci] = w + PADX*2;
}
for(var ci=0; ci<cols.length; ci++){
  if(cols[ci].type==='image') colW[ci] = IMG_W + PADX*2;
}
var totalW = 0;
for(var ci=0; ci<colW.length; ci++) totalW += colW[ci];

// note 换行
var noteLines = [];
if(note) noteLines = wrap(note, totalW - 8);

// 每列换行 + 行高
var wrapped = [];
var maxLines = 1;
for(var ri=0; ri<rows.length; ri++){
  wrapped[ri] = [];
  var rowMax = 1;
  for(var ci=0; ci<cols.length; ci++){
    var col = cols[ci];
    if(col.type==='image' || col.type==='merge'){ wrapped[ri][ci]=null; continue; }
    var v = rows[ri][col.key];
    if(v===null || v===undefined) v='';
    v = String(v);
    var maxW = colW[ci] - PADX*2;
    var lines = (col.key==='title'||col.key==='desc') ? wrap(v, maxW) : [v];
    wrapped[ri][ci] = lines;
    rowMax = Math.max(rowMax, lines.length);
  }
  maxLines = Math.max(maxLines, rowMax);
}

var ROW_H = Math.max(IMG + PADY*2, maxLines*LH + PADY*2);
var NOTE_H = noteLines.length > 0 ? noteLines.length*16 + 14 : 0;
var totalH = NOTE_H + HEADER_H + rows.length*ROW_H;

// 图片预加载
function loadImages(){
  var tasks = [];
  for(var ri=0; ri<rows.length; ri++){
    var src = rows[ri].image;
    if(!src){ rows[ri]._img = null; continue; }
    (function(ri, src){
      tasks.push(new Promise(function(resolve){
        var im = new Image();
        im.onload = function(){ rows[ri]._img = im; resolve(); };
        im.onerror = function(){ rows[ri]._img = null; resolve(); };
        im.src = src;
      }));
    })(ri, src);
  }
  return Promise.all(tasks);
}

loadImages().then(function(){
  var cv = document.getElementById('cv');
  cv.width = totalW*SCALE; cv.height = totalH*SCALE;
  cv.style.width = totalW+'px'; cv.style.height = totalH+'px';
  var ctx = cv.getContext('2d');
  ctx.scale(SCALE, SCALE);
  ctx.textBaseline = 'middle';

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, totalW, totalH);

  function text(s, x, y, align, font, color){
    ctx.font = font; ctx.fillStyle = color; ctx.textAlign = align;
    ctx.fillText(s, x, y);
  }

  var y = 0;
  if(noteLines.length > 0){
    var fnote = C.fs_note+'px '+C.font;
    for(var k=0; k<noteLines.length; k++){
      text(noteLines[k], 4, y+8, 'left', fnote, C.note_text);
      y += 16;
    }
    y += 14;
  }

  var tableTop = y;
  var fh = 'bold '+C.fs_h+'px '+C.font;
  var x = 0;
  for(var ci=0; ci<cols.length; ci++){
    var nm = cols[ci].name;
    if(nm.indexOf('/') >= 0){
      var parts = nm.split('/');
      text(parts[0]+'/', x+colW[ci]/2, tableTop+HEADER_H/2-8, 'center', fh, C.header_text);
      text(parts[1], x+colW[ci]/2, tableTop+HEADER_H/2+8, 'center', fh, C.header_text);
    } else {
      text(nm, x+colW[ci]/2, tableTop+HEADER_H/2, 'center', fh, C.header_text);
    }
    x += colW[ci];
  }
  y += HEADER_H;

  var fd = C.fs+'px '+C.font;
  // 计算 Top / Bottom 块范围
  var topStart = -1, topEnd = -1, botStart = -1, botEnd = -1;
  for(var ri=0; ri<rows.length; ri++){
    if(rows[ri].rank_group==='Top'){ if(topStart<0) topStart=ri; topEnd=ri; }
    else if(rows[ri].rank_group==='Bottom'){ if(botStart<0) botStart=ri; botEnd=ri; }
  }

  for(var ri=0; ri<rows.length; ri++){
    var x = 0;
    for(var ci=0; ci<cols.length; ci++){
      var col = cols[ci];
      if(col.type==='merge'){
        // 品类/类别 合并列, 在块中心画
        if(col.key==='category'){
          if(ri===0){
            var cy = tableTop + HEADER_H + rows.length*ROW_H/2;
            text(CATEGORY, x+colW[ci]/2, cy, 'center', fh, C.header_text);
          }
        } else if(col.key==='rank_group'){
          var isTopFirst = (ri===topStart);
          var isBotFirst = (ri===botStart);
          if(isTopFirst){
            var cyTop = tableTop + HEADER_H + (topStart+topEnd+1)*ROW_H/2;
            text('Top', x+colW[ci]/2, cyTop, 'center', fd, C.normal_text);
          } else if(isBotFirst){
            var cyBot = tableTop + HEADER_H + (botStart+botEnd+1)*ROW_H/2;
            text('Bottom', x+colW[ci]/2, cyBot, 'center', fd, C.normal_text);
          }
        }
      } else if(col.type==='image'){
        var im = rows[ri]._img;
        var cy = tableTop + HEADER_H + ri*ROW_H + ROW_H/2;
        if(im){
          ctx.drawImage(im, x+colW[ci]/2-IMG_W/2, cy-IMG/2, IMG_W, IMG);
        } else {
          ctx.strokeStyle = C.border;
          ctx.strokeRect(x+colW[ci]/2-IMG_W/2, cy-IMG/2, IMG_W, IMG);
        }
      } else if(col.type==='dual'){
        var cy = tableTop + HEADER_H + ri*ROW_H + ROW_H/2;
        var vt = rows[ri].vt || '';
        text(vt, x+PADX, cy, 'left', fd, C.normal_text);
      } else {
        var lines = wrapped[ri][ci];
        var cx = x + PADX;
        var totalTextH = lines.length*LH;
        var ty0 = tableTop + HEADER_H + ri*ROW_H + ROW_H/2 - totalTextH/2 + LH/2;
        for(var k=0; k<lines.length; k++){
          text(lines[k], cx, ty0 + k*LH, 'left', fd, C.normal_text);
        }
      }
      x += colW[ci];
    }
  }

  // 网格线
  ctx.strokeStyle = C.border;
  ctx.lineWidth = 1;
  var dataBottom = tableTop + HEADER_H + rows.length*ROW_H;
  // 竖线
  var cx = 0;
  for(var ci=0; ci<=cols.length; ci++){
    ctx.beginPath();
    ctx.moveTo(cx, tableTop); ctx.lineTo(cx, dataBottom);
    ctx.stroke();
    if(ci<cols.length) cx += colW[ci];
  }
  // 横线(分段, 跳过合并列内部)
  var colCatEnd = colW[0];
  var colRankEnd = colW[0] + colW[1];
  for(var i=0; i<=rows.length; i++){
    var ly = tableTop + HEADER_H + i*ROW_H;
    // 品类列范围 [0, colCatEnd]: 仅 i=0 和 i=rows.length 画(顶/底)
    // 类别列范围 [colCatEnd, colRankEnd]: Top内部/Bottom内部不画
    // 其余范围: 全画
    var skipCat = (i>0 && i<rows.length);
    var skipRank = false;
    if(i>topStart && i<=topEnd) skipRank = true;      // Top 块内部
    if(i>botStart && i<=botEnd) skipRank = true;      // Bottom 块内部
    // 分段画线
    var segs = [[0, colCatEnd, skipCat], [colCatEnd, colRankEnd, skipRank], [colRankEnd, totalW, false]];
    for(var s=0; s<segs.length; s++){
      var seg = segs[s];
      if(seg[2]) continue;
      ctx.beginPath();
      ctx.moveTo(seg[0], ly); ctx.lineTo(seg[1], ly);
      ctx.stroke();
    }
  }

  window.__REPORT_PNG = cv.toDataURL('image/png');
  document.title = 'DONE';
}).catch(function(e){
  document.title = 'ERR:' + e.message;
});
</script></body></html>"""

if __name__ == "__main__":
    main()