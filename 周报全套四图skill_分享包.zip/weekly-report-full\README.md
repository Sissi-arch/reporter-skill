# 周报全套四图（weekly-report-full）

把物料中台周报 Excel 一次性生成四张 PNG 图，统一输出到同一文件夹：

1. `周报.png` — 周报可视化图（条件格式高亮，来自 weekly-report-visual）
2. `动画.png` — 动画 TOP&BOTTOM case 列表图
3. `影剧综.png` — 影剧综 TOP&BOTTOM case 列表图
4. `纪录片.png` — 纪录片 TOP&BOTTOM case 列表图

## 触发词

- 生成周报全套
- 输出四张图
- 周报和 TOP/BOTTOM 一起出

## 实现

复用 `weekly-report-visual` 与 `top-bottom-case` 两个 skill 的生成脚本，通过浏览器 Canvas 渲染并导出 PNG，四张图输出到同一文件夹。