#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""接收浏览器 POST 的 base64 PNG 并按文件名保存。
用法: python save_images.py <输出目录> [端口]

浏览器 POST 到 /save/<filename>, body 为 dataURL(base64 PNG)。
例如: fetch('http://127.0.0.1:8766/save/list_4.png', {method:'POST', body: window.__REPORT_PNG})
"""
import http.server
import base64
import sys
import os
import re
import urllib.parse

def main():
    out_dir = sys.argv[1] if len(sys.argv) > 1 else "."
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 8766
    os.makedirs(out_dir, exist_ok=True)

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_POST(self):
            m = re.match(r"^/save/([^/]+)$", self.path)
            name = urllib.parse.unquote(m.group(1)) if m else "image.png"
            # 安全检查: 禁止路径穿越
            if ".." in name or "/" in name or "\\" in name:
                self.send_response(400)
                self.end_headers()
                return
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length).decode("utf-8")
            if "," in body:
                body = body.split(",", 1)[1]
            data = base64.b64decode(body)
            path = os.path.join(out_dir, name)
            with open(path, "wb") as f:
                f.write(data)
            self.send_response(200)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", "2")
            self.end_headers()
            self.wfile.write(b"ok")
        def do_OPTIONS(self):
            self.send_response(200)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()
        def log_message(self, *a):
            pass

    print("save server on %d -> %s" % (port, out_dir))
    http.server.HTTPServer(("127.0.0.1", port), Handler).serve_forever()

if __name__ == "__main__":
    main()